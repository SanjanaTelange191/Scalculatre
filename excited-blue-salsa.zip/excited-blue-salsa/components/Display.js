import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Display = ({ expression, result }) => (
  <View style={styles.display}>
    <Text style={styles.expression}>{expression}</Text>
    <Text style={styles.result}>{result}</Text>
  </View>
);

const styles = StyleSheet.create({
  display: {
    height: 150,
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    backgroundColor: '#e6e6e6',
    marginBottom: 20,
  },
  expression: { fontSize: 24, color: '#333' },
  result: { fontSize: 40, fontWeight: 'bold', color: '#000' },
});

export default Display;